---
name: demo-philosophy
description: Analyze observations and premises in a philosophy reading note
---

# Philosophy reading

Separate observations, premises, and conclusions. Preserve uncertainty.
